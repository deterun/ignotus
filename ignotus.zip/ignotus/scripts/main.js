try { require("biomass"); } catch (e) { Log.err("[biomass] " + e); }







// ============================================================
//  ДИАЛОГОВАЯ СИСТЕМА ДЛЯ MINDUSTRY v8 (исправленная версия)
//  Спрайты, масштабирование, функции, сменные портреты
//  + адаптация под мобильные устройства
//
//  ЧТО ИСПРАВЛЕНО:
//  1. Краш "State is not defined" (пауза игры) - путь к GameState.State
//     теперь ищется безопасно, а любая ошибка паузы НЕ мешает диалогу.
//  2. Ветка "Настроить" (next: 10 вёл в пустоту) - добавлена реплика №9.
//  3. Комментарий у AUTO_PAUSE соответствует коду.
//  4. Печать текста не зависит от Time.delta (на паузе он может стоять).
//  5. start() с неверным индексом больше не открывает пустое окно.
//  6. clear() прячет открытый диалог.
//  7. На телефоне в портретной ориентации портрет идёт НАД текстом.
// ============================================================

(function () {

    // === ПРЕФИКС МОДА ===
    // Спрайты мода лежат в атласе С ПРЕФИКСОМ внутреннего имени мода:
    // файл sprites/portrait-guard.png -> регион "ignotus-portrait-guard"
    // Должен совпадать с полем name в mod.hjson
    var MOD = "ignotus";

    // === ОПРЕДЕЛЕНИЕ МОБИЛЬНОЙ ПЛАТФОРМЫ ===
    // Core.mobile в JS не существует - используем Vars.mobile
    // или тип приложения через Core.app.getType()
    function isMobile() {
        try {
            if (typeof Vars !== "undefined" && Vars.mobile !== undefined) {
                return Vars.mobile === true;
            }
            var appType = Core.app.getType();
            return appType == Application.ApplicationType.android
                || appType == Application.ApplicationType.iOS;
        } catch (e) {
            print("[DIALOG] Mobile check failed: " + e);
            return false;
        }
    }


    // === РАЗМЕРЫ ЭКРАНА В ЕДИНИЦАХ ИНТЕРФЕЙСА ===
    // ВАЖНО: размеры UI в Mindustry задаются НЕ в пикселях, а в "единицах сцены".
    // На ПК они почти равны пикселям, а на телефоне экран в 2-3 раза плотнее,
    // и 1 единица = несколько пикселей. Core.graphics.getWidth() даёт ПИКСЕЛИ,
    // поэтому на телефоне диалог получался в разы шире экрана и вылезал за края.
    function sceneW() {
        try {
            var w = Core.scene.getWidth();
            if (w > 0) return w;
        } catch (e) {}
        try { return Core.graphics.getWidth() / Scl.scl(1); } catch (e2) {}
        return Core.graphics.getWidth();
    }

    function sceneH() {
        try {
            var h = Core.scene.getHeight();
            if (h > 0) return h;
        } catch (e) {}
        try { return Core.graphics.getHeight() / Scl.scl(1); } catch (e2) {}
        return Core.graphics.getHeight();
    }

    // === НАСТРОЙКИ ===
    // Размеры задаются В ДОЛЯХ экрана - это автоматически работает
    // и на ПК (1920x1080), и на телефоне (800x360) без правок кода
    var SCALE = {
        dialogWidthRatio: 0.80,        // ширина диалога: 80% экрана на ПК
        dialogWidthRatioMobile: 0.92,  // и 92% на телефоне
        maxDialogWidth: 600,           // потолок ширины только на ПК
        textHeightRatio: 0.15,         // высота текста: 15% высоты экрана
        minTextHeight: 70,
        maxTextHeight: 160,
        portraitRatio: 0.15,           // портрет: 15% меньшей стороны экрана
        minPortrait: 72,
        maxPortrait: 192,
        minTextWidth: 150              // минимальная ширина текста
    };

    // Базовые размеры кнопок (умножаются на скейл экрана)
    var BUTTONS = {
        width: 140,
        height: 44,
        choiceWidth: 160,
        choiceHeight: 40
    };

    // === ПАУЗА ИГРЫ ВО ВРЕМЯ ДИАЛОГА ===
    // true = игра останавливается при открытии диалога.
    // Чтобы ВЫКЛЮЧИТЬ паузу, поставь false.
    // В мультиплеере пауза невозможна - там просто не сработает.
    var AUTO_PAUSE = true;

    // === ЦВЕТА И СТИЛИ ===
    var COLORS = {
        text: Color.valueOf("e2e2e2"),
        accent: Color.valueOf("8fd157"),
        name: Color.valueOf("e8c66a"),
        background: Color.valueOf("1a1a1a"),
        border: Color.valueOf("e2e2e2")
    };

    // Нейтральный фон для вложенных таблиц.
    // Инициализируется ЛЕНИВО - Tex.pane ещё не готов при загрузке скрипта
    var emptyDrawable = null;

    // === ПЕРЕЧИСЛЕНИЕ СОСТОЯНИЙ ИГРЫ (paused / playing) ===
    // В скриптах НЕТ имени "State" - именно из-за него был краш.
    // Ищем перечисление безопасно, при неудаче пауза просто отключается.
    var gameStateEnum = null;
    var gameStateTried = false;

    function getGameStateEnum() {
        if (gameStateTried) return gameStateEnum;
        gameStateTried = true;

        // Способ 1: через полный путь Java-пакета
        try {
            var s1 = Packages.mindustry.core.GameState.State;
            if (s1 !== undefined && s1 !== null && s1.paused !== undefined) {
                gameStateEnum = s1;
            }
        } catch (e1) {
            print("[DIALOG] GameState path 1 failed: " + e1);
        }

        // Способ 2: через импортированное имя GameState
        if (gameStateEnum === null) {
            try {
                var s2 = GameState.State;
                if (s2 !== undefined && s2 !== null && s2.paused !== undefined) {
                    gameStateEnum = s2;
                }
            } catch (e2) {
                print("[DIALOG] GameState path 2 failed: " + e2);
            }
        }

        if (gameStateEnum === null) {
            print("[DIALOG] GameState enum not found - pause disabled");
        }
        return gameStateEnum;
    }

    // === ДАННЫЕ ДИАЛОГА (с портретами и функциями) ===
    // Структура:
    // {
    //   text: "текст реплики",
    //   portrait: "portrait-guard" (опционально - ID спрайта БЕЗ префикса мода),
    //   name: "Имя персонажа" (опционально),
    //   choices: [ { label: "текст", next: индекс, func: функция } ],
    //   end: true (последняя реплика в ветке),
    //   onShow: функция (вызывается при показе реплики),
    //   func: функция (вызывается после окончания печати)
    // }
    //
    // ИНДЕКСЫ РЕПЛИК:
    //   0-1  : старт
    //   2-3  : ветка "Кто ты?"
    //   4-6  : ветка "Что тут происходит?"
    //   7-9  : ветка ИИ. Из основного диалога НЕ достижима -
    //          запускается через DialogSystem.start(7)

    var dialogue = [
        // === ВЕТКА 1: СТАРТ ===
        // 0
        {
            text: "Привет! Я - страж этого блока.",
            portrait: "portrait-guard",
            name: "Страж",
            onShow: function() { print("[DIALOG] Начало диалога"); }
        },
        // 1
        {
            text: "Так что? С чего начнём?",
            portrait: "portrait-guard",
            name: "Страж",
            choices: [
                {
                    label: "Кто ты?",
                    next: 2,
                    func: function() {
                        print("[DIALOG] Выбран вариант: Кто ты?");
                    }
                },
                {
                    label: "Что тут происходит?",
                    next: 4,
                    func: function() {
                        print("[DIALOG] Выбран вариант: Что тут происходит?");
                    }
                },
                {
                    label: "Мне пора",
                    next: -1,
                    func: function() {
                        print("[DIALOG] Диалог прерван");
                    }
                }
            ]
        },

        // === ВЕТКА 2: КТО ТЫ? ===
        // 2
        {
            text: "Я страж. Сижу тут со времён... уже не помню.",
            portrait: "portrait-guard",
            name: "Страж"
        },
        // 3
        {
            text: "Впрочем, неважно. Держи совет: не доверяй блокам без текстур.",
            portrait: "portrait-guard",
            name: "Страж",
            end: true,
            func: function() {
                print("[DIALOG] Диалог завершён");
            }
        },

        // === ВЕТКА 3: ЧТО ТУТ ПРОИСХОДИТ? ===
        // 4
        {
            text: "Идёт война. За ресурсы, за территории, за выживание.",
            portrait: "portrait-mech",
            name: "Механизм"
        },
        // 5
        {
            text: "Я был создан для защиты этой местности.",
            portrait: "portrait-mech",
            name: "Механизм",
            func: function() {
                Call.sendChatMessage("[cyan]Механизм активирован");
            }
        },
        // 6
        {
            text: "Но теперь я просто диалоговый блок. Забавно, да?",
            portrait: "portrait-mech",
            name: "Механизм",
            end: true
        },

        // === ВЕТКА 4: СПЕЦИАЛЬНАЯ (ИИ) ===
        // Доступна только через DialogSystem.start(7)
        // 7
        {
            text: "Обнаружен новый пользователь. Запуск протокола общения.",
            portrait: "portrait-ai",
            name: "ИИ Система"
        },
        // 8
        {
            text: "Вы можете настроить меня под свои нужды.",
            portrait: "portrait-ai",
            name: "ИИ Система",
            choices: [
                {
                    label: "Настроить",
                    next: 9,   // ИСПРАВЛЕНО: было 10 (такой реплики нет)
                    func: function() {
                        if (typeof setupAI === "function") {
                            setupAI();
                        }
                    }
                },
                {
                    label: "Позже",
                    next: -1
                }
            ]
        },
        // 9 (НОВАЯ - финал ветки "Настроить")
        {
            text: "Настройки применены. Приятной работы, пользователь.",
            portrait: "portrait-ai",
            name: "ИИ Система",
            end: true,
            func: function() {
                if (typeof applyAISettings === "function") {
                    applyAISettings();
                }
            }
        }
    ];

    // === СОСТОЯНИЕ ===
    var dialog = null;
    var textLabel = null;
    var nameLabel = null;
    var portraitImage = null;
    var choiceTable = null;
    var nextButton = null;
    var currentLine = 0;
    var shownChars = 0;
    var charTimer = 0;
    var isTyping = false;
    var currentPortrait = null;      // последний успешно загруженный ID портрета
    var lastPortraitDrawable = null; // кеш последнего drawable портрета
    var forcedPortrait = null;       // принудительный портрет из startWithPortrait
    var realBlockName = null;
    var isDialogVisible = false;
    var wasPausedBefore = false;     // была ли игра на паузе ДО диалога
    var lastScreenWidth = 0;         // для пересборки при смене разрешения
    var lastScreenHeight = 0;

    // === УТИЛИТЫ МАСШТАБИРОВАНИЯ ===

    function getUIScale() {
        var smaller = Math.min(sceneW(), sceneH());
        var s = smaller / 720;
        if (s < 0.7) s = 0.7;
        if (s > 1.3) s = 1.3;
        return s;
    }

    function getScaledWidth() {
        var ratio = isMobile() ? SCALE.dialogWidthRatioMobile : SCALE.dialogWidthRatio;
        var targetWidth = sceneW() * ratio;

        // Потолок ширины - только на ПК
        if (!isMobile() && targetWidth > SCALE.maxDialogWidth) {
            targetWidth = SCALE.maxDialogWidth;
        }

        return Math.floor(targetWidth);
    }

    function getScaledTextHeight() {
        var height = sceneH() * SCALE.textHeightRatio;
        if (height < SCALE.minTextHeight) height = SCALE.minTextHeight;
        if (height > SCALE.maxTextHeight) height = SCALE.maxTextHeight;
        return Math.floor(height);
    }

    function getPortraitSize() {
        var baseSize = Math.min(sceneW(), sceneH());
        var size = baseSize * SCALE.portraitRatio;
        if (size < SCALE.minPortrait) size = SCALE.minPortrait;
        if (size > SCALE.maxPortrait) size = SCALE.maxPortrait;
        return Math.floor(size);
    }

    // Ширина текста: в обычной раскладке - рядом с портретом,
    // в "стопке" (телефон вертикально) - почти на всю ширину
    function getTextWidth(dialogWidth, portraitSize, stacked) {
        var w = stacked ? (dialogWidth - 60) : (dialogWidth - portraitSize - 60);
        if (w < SCALE.minTextWidth) w = SCALE.minTextWidth;
        return w;
    }

    // Нужна ли вертикальная раскладка (портрет НАД текстом)?
    // Только на телефоне и только если экран "стоит" вертикально
    function isStackedLayout() {
        return isMobile() && sceneW() < sceneH();
    }

    // === ПАУЗА ИГРЫ ===
    // Любая ошибка здесь ЛОВИТСЯ - пауза не должна ломать диалог.

    function pauseGame() {
        if (!AUTO_PAUSE) return;
        try {
            if (Vars.net.active()) return;   // в мультиплеере паузы нет
            var gs = getGameStateEnum();
            if (gs === null) return;
            wasPausedBefore = Vars.state.isPaused();
            if (!wasPausedBefore) {
                Vars.state.set(gs.paused);
            }
        } catch (e) {
            print("[DIALOG] pauseGame failed: " + e);
        }
    }

    function resumeGame() {
        if (!AUTO_PAUSE) return;
        try {
            if (Vars.net.active()) return;
            if (wasPausedBefore) return;     // игра и была на паузе - оставляем
            var gs = getGameStateEnum();
            if (gs === null) return;
            Vars.state.set(gs.playing);
        } catch (e) {
            print("[DIALOG] resumeGame failed: " + e);
        }
    }

    // === ЗАГРУЗКА ПОРТРЕТА ===
    // Core.atlas.find() НИКОГДА не возвращает null - при отсутствии спрайта
    // он возвращает error-регион. Поэтому проверяем через Core.atlas.has().
    function loadPortrait(portraitId) {
        if (portraitId === null || portraitId === undefined) return null;

        // Кеш: тот же ID - возвращаем готовый drawable
        if (portraitId === currentPortrait && lastPortraitDrawable !== null) {
            return lastPortraitDrawable;
        }

        var fullName = MOD + "-" + portraitId;
        if (!Core.atlas.has(fullName)) {
            print("[DIALOG] Portrait not found: " + fullName + ", trying default");
            fullName = MOD + "-dialog-portrait"; // запасной портрет
        }
        if (!Core.atlas.has(fullName)) {
            print("[DIALOG] Default portrait not found either, portrait empty");
            currentPortrait = null;
            lastPortraitDrawable = null;
            return null;
        }

        currentPortrait = portraitId;
        lastPortraitDrawable = new TextureRegionDrawable(Core.atlas.find(fullName));
        return lastPortraitDrawable;
    }

    // === ПОСТРОЕНИЕ UI ===
    function buildDialog() {
        if (emptyDrawable === null) {
            emptyDrawable = Tex.pane;
        }

        dialog = new BaseDialog("");
        dialog.addCloseButton();
        dialog.cont.center();

        var root = dialog.cont;
        root.defaults().pad(10);

        // Размеры для текущего экрана
        var stacked = isStackedLayout();
        var dialogWidth = getScaledWidth();
        var textHeight = getScaledTextHeight();
        var portraitSize = getPortraitSize();
        var textWidth = getTextWidth(dialogWidth, portraitSize, stacked);
        var uiScale = getUIScale();

        var btnW = Math.floor(BUTTONS.width * uiScale);
        var btnH = Math.floor(BUTTONS.height * uiScale);

        // === РАМКА (9-slice) ===
        var frameDrawable = null;
        var frameName = MOD + "-dialog-frame";

        if (Core.atlas.has(frameName)) {
            var frameRegion = Core.atlas.find(frameName);
            try {
                frameDrawable = new NinePatchDrawable(
                    new NinePatch(frameRegion, 32, 32, 32, 32)
                );
            } catch (e) {
                print("[DIALOG] NinePatch failed: " + e);
                frameDrawable = null;
            }
        } else {
            print("[DIALOG] Frame not found: " + frameName + ", using Tex.pane");
        }

        if (frameDrawable === null) {
            frameDrawable = Tex.pane;
        }

        root.table(frameDrawable, function (t) {
            t.defaults().pad(12);

            // === ПОРТРЕТ ===
            portraitImage = new Image();
            var portraitDrawable = loadPortrait("portrait-guard");
            if (portraitDrawable !== null) {
                portraitImage.setDrawable(portraitDrawable);
            }

            if (stacked) {
                // Телефон вертикально: портрет сверху, текст под ним
                t.add(portraitImage).size(portraitSize, portraitSize).top().padBottom(8).row();
            } else {
                // ПК и телефон горизонтально: портрет слева
                t.add(portraitImage).size(portraitSize, portraitSize).left().top().padRight(15);
            }

            // === ТЕКСТОВАЯ ОБЛАСТЬ ===
            t.table(emptyDrawable, function (info) {
                info.defaults().left().padBottom(4);

                var nameStyle = new Label.LabelStyle(Fonts.def, COLORS.name);
                nameLabel = new Label("", nameStyle);
                info.add(nameLabel).left().padBottom(8).row();

                var textStyle = new Label.LabelStyle(Fonts.def, COLORS.text);
                textLabel = new Label("", textStyle);
                textLabel.setWrap(true);
                textLabel.setAlignment(Align.left, Align.top);
                info.add(textLabel).width(textWidth).height(textHeight).grow().left().top().row();

                choiceTable = new Table();
                info.add(choiceTable).growX().left();
            }).grow().left().padLeft(stacked ? 0 : 10);
        }).grow().row();

        // === НИЖНЯЯ ПАНЕЛЬ КНОПОК ===
        root.table(emptyDrawable, function (buttons) {
            buttons.button("Пропустить", function () {
                dialog.hide();
                isDialogVisible = false;
            }).size(btnW, btnH).expandX().center();

            nextButton = buttons.button("Далее", function () { advance(); })
                .size(btnW, btnH).get();
        }).growX().right().padTop(5);

        // Срабатывает при ЛЮБОМ способе закрытия диалога
        dialog.hidden(function () {
            isDialogVisible = false;
            resumeGame();
        });
    }

    // === УПРАВЛЕНИЕ ДИАЛОГОМ ===
    function startDialogue(startIndex) {
        if (startIndex === undefined || startIndex === null) {
            startIndex = 0;
        }

        // Защита: неверный индекс не должен открывать пустое окно
        if (startIndex < 0 || startIndex >= dialogue.length) {
            print("[DIALOG] Bad start index: " + startIndex);
            return;
        }

        // Пересборка при смене разрешения (поворот телефона, смена окна)
        var w = Core.graphics.getWidth();
        var h = Core.graphics.getHeight();
        if (w !== lastScreenWidth || h !== lastScreenHeight) {
            if (dialog !== null) {
                dialog.hide();
                dialog = null;   // заставим buildDialog() собраться заново
            }
            lastScreenWidth = w;
            lastScreenHeight = h;
        }

        currentLine = startIndex;
        isDialogVisible = true;

        if (dialog === null) {
            buildDialog();
        }

        showLine();
        pauseGame();       // пауза ПОСЛЕ showLine, ПЕРЕД show()
        dialog.show();

        print("[DIALOG] Открыт диалог, стартовая реплика: " + startIndex);
    }

    function showLine() {
        if (currentLine < 0 || currentLine >= dialogue.length) {
            dialog.hide();
            isDialogVisible = false;
            return;
        }

        var line = dialogue[currentLine];
        shownChars = 0;
        charTimer = 0;
        isTyping = true;

        // Портрет (с учётом принудительного)
        var portraitId = forcedPortrait !== null ? forcedPortrait : line.portrait;
        if (portraitId) {
            var portraitDrawable = loadPortrait(portraitId);
            if (portraitDrawable !== null && portraitImage !== null) {
                portraitImage.setDrawable(portraitDrawable);
            }
        }

        // Имя
        if (line.name) {
            nameLabel.setText("[accent]" + line.name + "[]");
        } else {
            nameLabel.setText("");
        }

        // Очищаем текст и выборы
        textLabel.setText("");
        choiceTable.clear();

        // Кнопка "Далее"
        if (line.choices) {
            nextButton.setDisabled(true);
            nextButton.setText("Далее");
        } else {
            nextButton.setDisabled(false);
            nextButton.setText(line.end ? "Закрыть" : "Далее");
        }

        // onShow
        if (line.onShow && typeof line.onShow === "function") {
            try {
                line.onShow();
            } catch (e) {
                print("[DIALOG] onShow error: " + e);
            }
        }
    }

    // === ПЕЧАТНАЯ МАШИНКА ===
    var charsPerSecond = 30; // Скорость печати (символов в секунду)

    function updateTyping() {
        if (dialog === null || !isDialogVisible) return;

        // Поддержание паузы: если игрок открыл Esc-меню и закрыл его,
        // пауза могла слететь - восстанавливаем
        if (AUTO_PAUSE && isTyping) {
            try {
                var gs = getGameStateEnum();
                if (gs !== null && !Vars.net.active() && !Vars.state.isPaused() && !wasPausedBefore) {
                    Vars.state.set(gs.paused);
                }
            } catch (e) {
                // молча: пауза не критична
            }
        }

        if (!isTyping) return;

        // Подстраховка: если строка исчезла (после clear()), выходим
        if (currentLine < 0 || currentLine >= dialogue.length) return;

        var line = dialogue[currentLine];

        // ВАЖНО: берём время кадра напрямую, а не Time.delta -
        // на паузе Time.delta может быть нулевым, и текст бы замер.
        var dt = Core.graphics.getDeltaTime() * 60;
        if (dt > 6) dt = 6; // защита от скачков
        charTimer += dt;

        var need = 60 / charsPerSecond; // тиков на символ
        while (charTimer >= need && shownChars < line.text.length) {
            charTimer -= need;
            shownChars++;
        }

        textLabel.setText(line.text.substring(0, shownChars));

        if (shownChars >= line.text.length) {
            finishTyping();
        }
    }

    function finishTyping() {
        isTyping = false;

        if (currentLine < 0 || currentLine >= dialogue.length) {
            dialog.hide();
            isDialogVisible = false;
            return;
        }

        var line = dialogue[currentLine];
        textLabel.setText(line.text);

        // func
        if (line.func && typeof line.func === "function") {
            try {
                line.func();
            } catch (e) {
                print("[DIALOG] func error: " + e);
            }
        }

        if (line.choices) {
            nextButton.setDisabled(true);

            // На телефоне кнопки выбора идут ВЕРТИКАЛЬНО
            var vertical = isMobile() || line.choices.length > 2;

            var cs = getUIScale();
            var chW = Math.floor(BUTTONS.choiceWidth * cs);
            var chH = Math.floor(BUTTONS.choiceHeight * cs);

            for (var i = 0; i < line.choices.length; i++) {
                // Замыкание, чтобы каждая кнопка помнила свой choice
                (function (choice) {
                    var cell = choiceTable.button(choice.label, function () {
                        if (choice.func && typeof choice.func === "function") {
                            try { choice.func(); } catch (e) { print("[DIALOG] choice func error: " + e); }
                        }
                        if (choice.next === -1) {
                            dialog.hide();
                            isDialogVisible = false;
                        } else if (choice.next !== undefined && choice.next !== null) {
                            currentLine = choice.next;
                            showLine();
                        } else {
                            currentLine++;
                            showLine();
                        }
                    }).size(chW, chH);

                    if (vertical) {
                        cell.padBottom(6).left().row();
                    } else {
                        cell.padRight(8).left();
                    }
                })(line.choices[i]);
            }
        } else {
            nextButton.setDisabled(false);
        }
    }

    // === КНОПКА "ДАЛЕЕ" ===
    function advance() {
        if (!isDialogVisible) return;
        if (currentLine < 0 || currentLine >= dialogue.length) return;

        var line = dialogue[currentLine];

        // Если печатается - показать весь текст
        if (isTyping) {
            shownChars = line.text.length;
            finishTyping();
            return;
        }

        // Открыт выбор - "Далее" не должна его обходить
        if (line.choices) return;

        // Конец диалога
        if (line.end) {
            dialog.hide();
            isDialogVisible = false;
            return;
        }

        // Следующая реплика
        currentLine++;
        if (currentLine >= dialogue.length) {
            dialog.hide();
            isDialogVisible = false;
        } else {
            showLine();
        }
    }

    // === ПОИСК БЛОКА ===
    // Ищем и при загрузке скрипта, и по WorldLoadEvent - иначе при
    // перезагрузке мода в уже загруженном мире блок не найдётся
    function findDialogBlock() {
        var blocks = Vars.content.blocks();
        for (var i = 0; i < blocks.size; i++) {
            var b = blocks.get(i);
            if (b.name != null && b.name.indexOf("dialog-block") !== -1) {
                realBlockName = b.name;
                print("[DIALOG] Block found: " + realBlockName);
                return;
            }
        }
    }

    findDialogBlock(); // при загрузке скрипта
    Events.on(EventType.WorldLoadEvent, function (e) {
        findDialogBlock();
    });

    // === ТАП ПО БЛОКУ ===
    Events.on(EventType.TapEvent, function (e) {
        if (realBlockName === null) return;
        if (e.tile == null || e.tile.block() == null) return;
        if (e.tile.block().name === realBlockName) {
            if (isDialogVisible) return; // диалог уже открыт - игнорируем тап
            startDialogue(0); // Всегда начинаем с начала
        }
    });

    // === ПЕЧАТНАЯ МАШИНКА (каждый кадр) ===
    Events.run(Trigger.update, function () {
        updateTyping();
    });

    // === ПУБЛИЧНЫЙ API ===
    global.DialogSystem = {
        // Запуск диалога с конкретного индекса
        start: function(index) {
            startDialogue(index);
        },

        // Запуск с принудительным портретом
        startWithPortrait: function(portraitId, index) {
            forcedPortrait = portraitId;
            startDialogue(index);
        },

        // Сброс принудительного портрета
        clearForcedPortrait: function() {
            forcedPortrait = null;
        },

        // Скорость печати (символов в секунду)
        setSpeed: function(charsPerSec) {
            charsPerSecond = charsPerSec;
        },

        // Включить/выключить паузу игры во время диалога
        setAutoPause: function(enabled) {
            AUTO_PAUSE = enabled ? true : false;
        },

        // Добавление новой реплики (для динамических диалогов)
        addLine: function(lineData) {
            dialogue.push(lineData);
            return dialogue.length - 1; // Возвращаем индекс
        },

        // Очистка диалога (если он открыт - сначала закрываем)
        clear: function() {
            if (dialog !== null && isDialogVisible) {
                dialog.hide();
                isDialogVisible = false;
            }
            isTyping = false;
            dialogue = [];
            currentLine = 0;
        },

        // Текущее состояние
        getState: function() {
            return {
                currentLine: currentLine,
                isTyping: isTyping,
                isVisible: isDialogVisible
            };
        }
    };

    // === КОМАНДА ДЛЯ КОНСОЛИ ===
    global.__dialog = function(startIndex) {
        if (startIndex === undefined) startIndex = 0;
        startDialogue(startIndex);
    };

})();

// ============================================================
//  ПРИМЕР ИСПОЛЬЗОВАНИЯ API:
//
//  DialogSystem.start(0);           // Обычный запуск
//  DialogSystem.start(7);           // Ветка ИИ (только отсюда!)
//  DialogSystem.setSpeed(50);       // Быстрая печать
//  DialogSystem.setAutoPause(true); // Включить паузу игры в диалоге
//  DialogSystem.addLine({           // Добавить реплику
//      text: "Динамическая реплика",
//      portrait: "portrait-ai",
//      name: "Динамический ИИ"
//  });
// ============================================================










































