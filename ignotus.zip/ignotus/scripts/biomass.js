// ============================================================
//  biomass.js — «неметалломасса» (живой яридий), система очков
//
//  Подключение: в конце scripts/main.js добавить строку
//      try { require("biomass"); } catch (e) { Log.err("[biomass] " + e); }
//
//  Блоки (имена с префиксом мода), делаются в hjson:
//      ignotus-bio-heart   4x4, update: true
//      ignotus-bio-embryo  2x2, update: true
//      ignotus-bio-cell    1x1, update: true    (активный край сети)
//      ignotus-bio-dead    1x1, update НЕ нужен (застывшая стена)
//  Любые другие блоки (заводы, турели...) перечисляются в STRUCTS ниже.
//  Скрипт только ставит их по имени, как они работают — решает hjson.
//
//  Как это работает:
//   * Масса «ест» тепло. Клетка, выросшая рядом с горячим тайлом
//     (разлом) или горячим блоком, даёт очки каждую секунду.
//   * Очки делятся на два запаса: на рост (клетки) и на постройки
//     (заводы, турели, зародыши сердец).
//   * Рост: активная клетка (край сети) тратит очки и занимает соседний
//     тайл; направление смещено к теплу. Без очков рост стоит.
//   * Постройки из STRUCTS ставятся рядом с краем сети, когда хватает
//     очков и не достигнут их лимит.
//   * Клетка без свободных соседей застывает (bio-dead) и просыпается,
//     если ей нанесли урон, рядом освободилось место или появилась
//     чужая постройка.
//   * Активные клетки разъедают чужие постройки рядом.
//   * Зародыш за очки превращается в сердце.
// ============================================================
(function () {
    "use strict";

    // ===== НАСТРОЙКИ =====
    var CFG = {
        debug: false,            // true: раз в скан писать в лог очки и статистику

        // --- очки ---
        startPoints: 10,         // стартовый запас (и на рост, и на постройки)
        baseIncome: 0.3,         // очков в секунду без тепла
        heatIncome: 10.0,         // очков в секунду за каждую «питающуюся» клетку
        feedRadius: 2,           // тайлов: клетка так близко к теплу питается
        buildShare: 0.4,         // доля дохода на постройки (остальное на рост)
        maxPoints: 300,          // потолок каждого из запасов

        // --- рост ---
        cellCost: 1,             // цена одной клетки
        growInterval: 2,        // тиков между порциями роста (60 тиков = 1 с)
        growPerStep: 6,          // максимум клеток за порцию
        heatSeek: 0.75,          // шанс выбрать тайл ближе к теплу (иначе случайный)
        maxCells: 150000,          // потолок числа клеток (защита от лагов)

        // --- сердца ---
        embryoCost: 400,          // цена зародыша
        heartCost: 180,           // цена превращения зародыша в сердце
        maxHearts: 6,            // сердца + зародыши вместе
        embryoMinDist: 17,        // расстояние зародыша от сердца (тайлы)
        embryoMaxDist: 160,

        // --- прочее ---
        regenInterval: 30,       // каждая клетка лечится раз в столько тиков
        regenPercent: 0.02,      // доля максимального HP за одно лечение
        wakeChance: 0.05,        // шанс проверки «пора проснуться» у застывшей клетки
        corrodeDamage: 150,       // урон чужой постройке рядом за срабатывание
        chillDuration: 300,      // сколько тиков держится метка охлаждения
        chillBonusDamage: 6,     // доп. урон мимо брони за попадание холодом
        scanInterval: 600,       // как часто искать постройки среди обновляемых (тики)
        heatSpotLimit: 600       // потолок точек тепла
    };

    // Постройки за очки. Порядок = приоритет. Меняйте имена на свои блоки.
    //   name         имя блока с префиксом мода
    //   cost         цена из запаса на постройки
    //   max          сколько таких блоков максимум на карту
    //   minDistSame  минимум тайлов между такими блоками
    //   minDistHeart минимум тайлов до ближайшего сердца (необязательно)
    var STRUCTS = [
        { name: "ignotus-bio-turret",  cost: 40,  max: 1000, minDistSame: 6 },
        { name: "ignotus-bio-factory", cost: 120, max: 5,  minDistSame: 10, minDistHeart: 6 }
    ];

    // Блоки с этими именами накладывают охлаждение (имя с префиксом мода)
    var COLD_TURRETS = { "ignotus-kryo-turret": true };

    // ===== СОСТОЯНИЕ =====
    var B = { heart: null, embryo: null, cell: null, dead: null };
    var ready = false;
    var failed = 0;
    var tick = 0;

    var growPts = 0, buildPts = 0;

    var known = {};      // pos -> true, все зарегистрированные постройки массы
    var all = [];        // pos построек массы (для регенерации)
    var active = [];     // pos активных клеток (край)
    var hearts = [];     // pos больших сердец
    var embryos = {};    // pos -> тик рождения
    var chilled = {};    // pos -> тик, до которого клетка охлаждена
    var feederSet = {};  // pos -> true, клетки у тепла (дают очки)
    var structs = {};    // имя блока -> [pos]
    var structBlocks = {};   // имя -> блок (кэш)
    var structWarned = {};
    var heatX = [], heatY = [];            // точки тепла (тайлы)
    var floorHeatX = [], floorHeatY = [];  // тепло пола (считается один раз)
    var regenCursor = 0;

    var HEAT_ATTR = null;
    var HEAT_BLOCK = null;

    var NX = [1, 0, -1, 0];
    var NY = [0, 1, 0, -1];

    // ===== УТИЛИТЫ =====
    function log(msg) { try { Log.info("[biomass] " + msg); } catch (e) {} }
    function err(msg) { try { Log.err("[biomass] " + msg); } catch (e) {} }

    function loadBlocks() {
        B.heart = Vars.content.block("ignotus-bio-heart");
        B.embryo = Vars.content.block("ignotus-bio-embryo");
        B.cell = Vars.content.block("ignotus-bio-cell");
        B.dead = Vars.content.block("ignotus-bio-dead");
        try { HEAT_ATTR = Packages.mindustry.world.meta.Attribute.heat; } catch (e) { HEAT_ATTR = null; }
        try { HEAT_BLOCK = Packages.mindustry.world.blocks.heat.HeatBlock; } catch (e2) { HEAT_BLOCK = null; }
        structBlocks = {};
        return B.heart != null && B.embryo != null && B.cell != null && B.dead != null;
    }

    function kindOf(block) {
        if (block === B.cell) return "cell";
        if (block === B.dead) return "dead";
        if (block === B.heart) return "heart";
        if (block === B.embryo) return "embryo";
        return null;
    }

    function structDefByName(name) {
        for (var i = 0; i < STRUCTS.length; i++) if (STRUCTS[i].name === name) return STRUCTS[i];
        return null;
    }

    function removeFrom(arr, pos) {
        var i = arr.indexOf(pos);
        if (i >= 0) { arr[i] = arr[arr.length - 1]; arr.pop(); }
    }

    function register(b) {
        var pos = b.tile.pos();
        var kind = kindOf(b.block);
        if (kind == null) {
            // блок из списка построек?
            var nm = String(b.block.name);
            if (structDefByName(nm) != null) {
                if (!structs[nm]) structs[nm] = [];
                if (structs[nm].indexOf(pos) < 0) structs[nm].push(pos);
            }
            return;
        }
        if (!known[pos]) {
            known[pos] = true; all.push(pos);
            if ((kind == "cell" || kind == "dead") && heatX.length > 0 &&
                heatDist(b.tile.x, b.tile.y) <= CFG.feedRadius) feederSet[pos] = true;
        }
        if (kind == "cell" && active.indexOf(pos) < 0) active.push(pos);
        if (kind == "heart" && hearts.indexOf(pos) < 0) hearts.push(pos);
        if (kind == "embryo" && embryos[pos] === undefined) embryos[pos] = tick;
    }

    function forget(pos) {
        delete known[pos];
        delete chilled[pos];
        delete embryos[pos];
        delete feederSet[pos];
        removeFrom(hearts, pos);
        removeFrom(active, pos);
    }

    function reset() {
        known = {}; all = []; active = []; hearts = []; embryos = {};
        chilled = {}; feederSet = {}; structs = {}; heatX = []; heatY = [];
        floorHeatX = []; floorHeatY = [];
        regenCursor = 0; tick = 0;
        growPts = CFG.startPoints; buildPts = CFG.startPoints;
    }

    // ===== ГЕОМЕТРИЯ =====
    function footLo(size) { return -Math.floor((size - 1) / 2); }
    function footHi(size) { return Math.floor(size / 2); }

    function canGrow(t) {
        if (t == null) return false;
        if (t.block() !== Blocks.air) return false;
        if (t.floor().isDeep()) return false;
        return true;
    }

    // Свободны ли тайлы области; свои клетки и зародыши считаются свободными
    function areaOk(cx, cy, size, team) {
        var lo = footLo(size), hi = footHi(size);
        for (var dx = lo; dx <= hi; dx++) {
            for (var dy = lo; dy <= hi; dy++) {
                var t = Vars.world.tile(cx + dx, cy + dy);
                if (t == null) return false;
                if (t.floor().isDeep()) return false;
                if (t.block() === Blocks.air) continue;
                var b = t.build;
                if (b == null) return false; // статичная стена
                var k = kindOf(b.block);
                if (k == null || k == "heart" || b.team != team) return false;
            }
        }
        return true;
    }

    // Все тайлы области полностью свободны (для заводов и турелей)
    function footFree(ox, oy, size) {
        var lo = footLo(size), hi = footHi(size);
        for (var dx = lo; dx <= hi; dx++) {
            for (var dy = lo; dy <= hi; dy++) {
                if (!canGrow(Vars.world.tile(ox + dx, oy + dy))) return false;
            }
        }
        return true;
    }

    function clearArea(cx, cy, size) {
        var lo = footLo(size), hi = footHi(size);
        for (var dx = lo; dx <= hi; dx++) {
            for (var dy = lo; dy <= hi; dy++) {
                var t = Vars.world.tile(cx + dx, cy + dy);
                if (t != null && t.block() !== Blocks.air) {
                    removeFrom(active, t.pos());
                    t.setNet(Blocks.air);
                }
            }
        }
    }

    // Свободные тайлы вокруг постройки (только по сторонам)
    function ringFree(b) {
        var s = b.block.size, lo = footLo(s), hi = footHi(s);
        var x0 = b.tile.x + lo - 1, x1 = b.tile.x + hi + 1;
        var y0 = b.tile.y + lo - 1, y1 = b.tile.y + hi + 1;
        var out = [], x, y, t;
        for (x = x0 + 1; x <= x1 - 1; x++) {
            t = Vars.world.tile(x, y0); if (canGrow(t)) out.push(t);
            t = Vars.world.tile(x, y1); if (canGrow(t)) out.push(t);
        }
        for (y = y0 + 1; y <= y1 - 1; y++) {
            t = Vars.world.tile(x0, y); if (canGrow(t)) out.push(t);
            t = Vars.world.tile(x1, y); if (canGrow(t)) out.push(t);
        }
        return out;
    }

    // Есть ли рядом постройка чужой команды
    function enemyNear(c) {
        for (var i = 0; i < 4; i++) {
            var n = Vars.world.tile(c.tile.x + NX[i], c.tile.y + NY[i]);
            if (n == null) continue;
            var nb = n.build;
            if (nb != null && nb.team !== c.team && kindOf(nb.block) == null) return true;
        }
        return false;
    }

    // Едкость: активная клетка разъедает чужие постройки рядом. true, если такие есть.
    function corrode(c) {
        var touched = false;
        for (var i = 0; i < 4; i++) {
            var n = Vars.world.tile(c.tile.x + NX[i], c.tile.y + NY[i]);
            if (n == null) continue;
            var nb = n.build;
            if (nb != null && nb.team !== c.team && kindOf(nb.block) == null) {
                nb.damage(CFG.corrodeDamage);
                touched = true;
            }
        }
        return touched;
    }

    // ===== ТЕПЛО =====
    function scanFloorHeat() {
        floorHeatX = []; floorHeatY = [];
        if (HEAT_ATTR == null) return;
        var w = Vars.world.width(), h = Vars.world.height();
        for (var x = 0; x < w; x++) {
            for (var y = 0; y < h; y++) {
                var t = Vars.world.tile(x, y);
                if (t == null) continue;
                var v = t.floor().attributes.get(HEAT_ATTR);
                if (v > 0.05) { floorHeatX.push(x); floorHeatY.push(y); }
            }
        }
    }

    function rebuildHeat(buildHeat) {
        var xs = [], ys = [], i;
        var step = Math.max(1, Math.ceil(floorHeatX.length / CFG.heatSpotLimit));
        for (i = 0; i < floorHeatX.length; i += step) { xs.push(floorHeatX[i]); ys.push(floorHeatY[i]); }
        for (i = 0; i < buildHeat.length; i += 2) { xs.push(buildHeat[i]); ys.push(buildHeat[i + 1]); }
        heatX = xs; heatY = ys;
    }

    // Расстояние (тайлы) до ближайшей точки тепла; 9999 если тепла нет
    function heatDist(x, y) {
        var best = 9999;
        for (var i = 0; i < heatX.length; i++) {
            var dx = heatX[i] - x, dy = heatY[i] - y;
            var d = dx * dx + dy * dy;
            if (d < best) best = d;
        }
        return best == 9999 ? 9999 : Math.sqrt(best);
    }

    // ===== СКАНИРОВАНИЕ =====
    // Быстрый скан: только обновляемые постройки (Groups.build).
    function scan() {
        var buildHeat = [];
        Groups.build.each(function (b) {
            if (b == null || b.tile == null) return;
            if (kindOf(b.block) != null || structDefByName(String(b.block.name)) != null) {
                register(b);
            } else if (HEAT_BLOCK != null) {
                try {
                    if (b instanceof HEAT_BLOCK && b.heat() > 0.1) {
                        buildHeat.push(b.tile.x, b.tile.y);
                    }
                } catch (e) { HEAT_BLOCK = null; }
            }
        });
        rebuildHeat(buildHeat);
        if (CFG.debug) {
            log("скан: очки рост " + Math.floor(growPts) + ", постройки " + Math.floor(buildPts) +
                ", питающихся клеток " + countFeeders() + ", сердец " + hearts.length +
                ", построек массы " + all.length + ", активных " + active.length);
        }
    }

    // Полный обход тайлов: находит и застывшие клетки. Один раз при загрузке.
    function scanTiles() {
        var w = Vars.world.width(), h = Vars.world.height();
        for (var x = 0; x < w; x++) {
            for (var y = 0; y < h; y++) {
                var t = Vars.world.tile(x, y);
                if (t == null) continue;
                var b = t.build;
                if (b != null && b.tile === t && kindOf(b.block) != null) register(b);
            }
        }
    }

    // ===== ОЧКИ =====
    function countFeeders() {
        var n = 0;
        for (var k in feederSet) n++;
        return n;
    }

    function incomeStep() {
        var f = 0;
        for (var k in feederSet) {
            var b = Vars.world.build(Number(k));
            var kind = b == null ? null : kindOf(b.block);
            if (kind == "cell" || kind == "dead") f++;
            else delete feederSet[k];
        }
        var inc = CFG.baseIncome + f * CFG.heatIncome;
        growPts = Math.min(CFG.maxPoints, growPts + inc * (1 - CFG.buildShare));
        buildPts = Math.min(CFG.maxPoints, buildPts + inc * CFG.buildShare);
    }

    // ===== РОСТ =====
    // Ставит клетку. true, если получилось.
    function spawnCell(t, team) {
        t.setNet(B.cell, team, 0);
        if (t.build == null) return false;
        var pos = t.pos();
        known[pos] = true;
        all.push(pos);
        active.push(pos);
        if (heatX.length > 0 && heatDist(t.x, t.y) <= CFG.feedRadius) feederSet[pos] = true;
        return true;
    }

    function convertToDead(b) {
        var t = b.tile, team = b.team, pos = t.pos();
        var frac = b.health / b.maxHealth;
        removeFrom(active, pos);
        t.setNet(B.dead, team, 0);
        if (t.build != null) t.build.health = t.build.maxHealth * frac;
    }

    // Выбор тайла (смещён к теплу) и постановка клетки. true, если поставили.
    function tryGrow(src, cand) {
        var pick = null, i;
        if (Math.random() < CFG.heatSeek && heatX.length > 0) {
            var bestD = 99999;
            for (i = 0; i < cand.length; i++) {
                var d = heatDist(cand[i].x, cand[i].y) + Math.random() * 0.5;
                if (d < bestD) { bestD = d; pick = cand[i]; }
            }
        }
        if (pick == null) pick = cand[(Math.random() * cand.length) | 0];
        return spawnCell(pick, src.team);
    }

    function growStep() {
        if (growPts < CFG.cellCost) return;
        if (all.length >= CFG.maxCells) return;

        var srcs = [], i, b;
        for (i = hearts.length - 1; i >= 0; i--) {
            b = Vars.world.build(hearts[i]);
            if (b == null || b.block !== B.heart) { forget(hearts[i]); continue; }
            srcs.push(b);
        }
        for (var k in embryos) {
            b = Vars.world.build(Number(k));
            if (b == null || b.block !== B.embryo) { forget(Number(k)); continue; }
            srcs.push(b);
        }
        if (srcs.length == 0) return; // без сердца рост стоит

        var budget = Math.min(CFG.growPerStep, Math.floor(growPts / CFG.cellCost));

        // 1) от источников (сердце, зародыш)
        var s = srcs[(Math.random() * srcs.length) | 0];
        var cand = ringFree(s);
        if (cand.length > 0 && budget > 0 && tryGrow(s, cand)) { growPts -= CFG.cellCost; budget--; }

        // 2) от активных клеток
        var attempts = Math.min(CFG.growPerStep, active.length);
        for (i = 0; i < attempts && budget > 0; i++) {
            if (active.length == 0) break;
            var idx = (Math.random() * active.length) | 0;
            var pos = active[idx];
            var c = Vars.world.build(pos);
            if (c == null || c.block !== B.cell) {
                active[idx] = active[active.length - 1]; active.pop();
                continue;
            }
            var touched = corrode(c);
            var free = ringFree(c);
            if (free.length == 0) {
                // не застываем, пока клетка упирается в чужую постройку или не залечена
                if (!touched && c.health >= c.maxHealth - 1) convertToDead(c);
                continue;
            }
            if (tryGrow(c, free)) { growPts -= CFG.cellCost; budget--; }
        }
    }

    // ===== СЕРДЦА И ЗАРОДЫШИ =====
    function countEmbryos() {
        var n = 0;
        for (var k in embryos) n++;
        return n;
    }

    // true, если зародыш поставлен
    function trySpawnEmbryo(heart) {
        var team = heart.team;
        var best = null, bestD = 99999;
        for (var tries = 0; tries < 14; tries++) {
            var ang = Math.random() * Math.PI * 2;
            var dist = CFG.embryoMinDist + Math.random() * (CFG.embryoMaxDist - CFG.embryoMinDist);
            var x = Math.round(heart.tile.x + Math.cos(ang) * dist);
            var y = Math.round(heart.tile.y + Math.sin(ang) * dist);
            if (!areaOk(x, y, 2, team)) continue;
            var d = heatX.length > 0 ? heatDist(x, y) : Math.random() * 100;
            if (d < bestD) { bestD = d; best = Vars.world.tile(x, y); }
        }
        if (best == null) return false;
        clearArea(best.x, best.y, 2);
        best.setNet(B.embryo, team, 0);
        if (best.build == null) return false;
        var pos = best.pos();
        known[pos] = true; all.push(pos);
        embryos[pos] = tick;
        return true;
    }

    // true, если зародыш стал сердцем
    function matureEmbryo(pos) {
        var e = Vars.world.build(pos);
        if (e == null || e.block !== B.embryo) { forget(pos); return false; }
        var t = e.tile, team = e.team;
        if (!areaOk(t.x, t.y, 4, team)) return false;
        clearArea(t.x, t.y, 4);
        t.setNet(B.heart, team, 0);
        if (t.build == null) return false;
        delete embryos[pos];
        var hp = t.pos();
        known[hp] = true;
        if (all.indexOf(hp) < 0) all.push(hp);
        if (hearts.indexOf(hp) < 0) hearts.push(hp);
        return true;
    }

    // ===== ПОСТРОЙКИ ЗА ОЧКИ =====
    function structBlock(def) {
        if (structBlocks[def.name] === undefined) {
            structBlocks[def.name] = Vars.content.block(def.name);
            if (structBlocks[def.name] == null && !structWarned[def.name]) {
                structWarned[def.name] = true;
                err("блок из STRUCTS не найден, пропускаю: " + def.name);
            }
        }
        return structBlocks[def.name];
    }

    function structCount(name) {
        var arr = structs[name];
        if (!arr) return 0;
        for (var i = arr.length - 1; i >= 0; i--) {
            var b = Vars.world.build(arr[i]);
            if (b == null || String(b.block.name) !== name) { arr[i] = arr[arr.length - 1]; arr.pop(); }
        }
        return arr.length;
    }

    function tooClose(positions, x, y, minDist) {
        var min2 = minDist * minDist;
        for (var i = 0; i < positions.length; i++) {
            var t = Vars.world.tile(positions[i]);
            if (t == null) continue;
            var dx = t.x - x, dy = t.y - y;
            if (dx * dx + dy * dy < min2) return true;
        }
        return false;
    }

    // Ставит блок рядом со случайной активной клеткой. true, если поставили.
    function tryPlaceStruct(def, blk) {
        if (active.length == 0) return false;
        var size = blk.size, lo = footLo(size), hi = footHi(size);
        for (var tries = 0; tries < 10; tries++) {
            var c = Vars.world.build(active[(Math.random() * active.length) | 0]);
            if (c == null || c.block !== B.cell) continue;
            var d = (Math.random() * 4) | 0;
            var dx = NX[d], dy = NY[d];
            var ox = dx > 0 ? c.tile.x + 1 - lo : (dx < 0 ? c.tile.x - 1 - hi : c.tile.x);
            var oy = dy > 0 ? c.tile.y + 1 - lo : (dy < 0 ? c.tile.y - 1 - hi : c.tile.y);
            if (!footFree(ox, oy, size)) continue;
            if (def.minDistSame && structs[def.name] && tooClose(structs[def.name], ox, oy, def.minDistSame)) continue;
            if (def.minDistHeart && tooClose(hearts, ox, oy, def.minDistHeart)) continue;
            var t = Vars.world.tile(ox, oy);
            if (t == null) continue;
            t.setNet(blk, c.team, 0);
            if (t.build == null) continue;
            if (!structs[def.name]) structs[def.name] = [];
            structs[def.name].push(t.pos());
            return true;
        }
        return false;
    }

    function spendStep() {
        if (hearts.length == 0 && countEmbryos() == 0) return; // без сердца ничего не строим
        var i;

        // 1) постройки по списку
        for (i = 0; i < STRUCTS.length; i++) {
            var def = STRUCTS[i];
            if (buildPts < def.cost) continue;
            var blk = structBlock(def);
            if (blk == null) continue;
            if (structCount(def.name) >= def.max) continue;
            if (tryPlaceStruct(def, blk)) buildPts -= def.cost;
        }

        // 2) зародыш -> сердце (первый, который доступен)
        if (buildPts >= CFG.heartCost) {
            for (var k in embryos) {
                if (matureEmbryo(Number(k))) { buildPts -= CFG.heartCost; break; }
            }
        }

        // 3) новый зародыш
        if (buildPts >= CFG.embryoCost && hearts.length > 0 &&
            hearts.length + countEmbryos() < CFG.maxHearts) {
            var h = Vars.world.build(hearts[(Math.random() * hearts.length) | 0]);
            if (h != null && h.block === B.heart && trySpawnEmbryo(h)) buildPts -= CFG.embryoCost;
        }
    }

    // ===== РЕГЕНЕРАЦИЯ И ПРОБУЖДЕНИЕ =====
    function regenStep() {
        var n = all.length;
        if (n == 0) return;
        var per = Math.ceil(n / CFG.regenInterval);
        for (var i = 0; i < per && all.length > 0; i++) {
            if (regenCursor >= all.length) regenCursor = 0;
            var pos = all[regenCursor];
            var b = Vars.world.build(pos);
            if (b == null || kindOf(b.block) == null) {
                all[regenCursor] = all[all.length - 1];
                all.pop();
                forget(pos);
                continue;
            }

            // застывшая клетка просыпается: урон, свободное место рядом или чужая постройка
            if (b.block === B.dead) {
                var hurt = b.health < b.maxHealth - 1;
                if (hurt || (Math.random() < CFG.wakeChance && (ringFree(b).length > 0 || enemyNear(b)))) {
                    var frac = b.health / b.maxHealth, tt = b.tile, tm = b.team;
                    tt.setNet(B.cell, tm, 0);
                    if (tt.build != null) tt.build.health = tt.build.maxHealth * frac;
                    active.push(pos);
                    regenCursor++;
                    continue;
                }
            }

            var ch = chilled[pos];
            if (ch !== undefined) {
                if (ch > tick) { regenCursor++; continue; }
                delete chilled[pos];
            }
            var maxHp = b.block.health;
            if (b.health < maxHp) b.heal(maxHp * CFG.regenPercent);
            regenCursor++;
        }
    }

    // ===== СОБЫТИЯ =====
    // Охлаждение. Если события нет в этой версии игры, скрипт всё равно работает.
    try {
        Events.on(EventType.BuildDamageEvent, function (e) {
            try {
                if (!ready) return;
                var b = e.build;
                if (b == null || kindOf(b.block) == null) return;
                var src = e.source;
                if (src == null) return;
                var o = src.owner;
                if (o == null || o.block === undefined || !COLD_TURRETS[o.block.name]) return;
                chilled[b.tile.pos()] = tick + CFG.chillDuration;
                try { b.damagePierce(CFG.chillBonusDamage); } catch (e2) { b.damage(CFG.chillBonusDamage); }
            } catch (e3) { /* не ломаем игру из-за события */ }
        });
    } catch (e4) {
        err("BuildDamageEvent недоступен, охлаждение отключено: " + e4);
    }

    // Мгновенная регистрация сердец и зародышей, поставленных извне (редактор, консоль).
    try {
        Events.on(EventType.TileChangeEvent, function (e) {
            if (!ready || e.tile == null) return;
            var t = e.tile, b = t.build;
            if (b == null || b.tile !== t) return;
            var k = kindOf(b.block);
            if (k == "heart" || k == "embryo") register(b);
        });
    } catch (e5) {
        err("TileChangeEvent недоступен, сердца подхватываются сканом: " + e5);
    }

    // ===== ЗАПУСК =====
    Events.on(EventType.WorldLoadEvent, function () {
        ready = false;
        reset();
        failed = 0;
        Time.run(45, function () {
            try {
                if (!loadBlocks()) { err("блоки не найдены, проверь имена (ignotus-bio-*)"); return; }
                scanFloorHeat();
                rebuildHeat([]);   // тепло пола нужно до регистрации клеток
                scan();
                scanTiles();
                ready = true;
                log("запущено: сердец " + hearts.length + ", построек массы " + all.length +
                    ", точек тепла " + heatX.length);
            } catch (e) { err("старт: " + e); }
        });
    });

    Events.run(EventType.Trigger.update, function () {
        if (!ready) return;
        if (Vars.net.client()) return;
        if (!Vars.state.isGame() || Vars.state.isPaused()) return;
        tick++;
        try {
            if (tick % 60 == 0) { incomeStep(); spendStep(); }
            if (tick % CFG.growInterval == 0) growStep();
            regenStep();
            if (tick % CFG.scanInterval == 0) scan();
        } catch (e) {
            failed++;
            err("тик: " + e);
            if (failed >= 5) { ready = false; err("отключено после 5 ошибок"); }
        }
    });
})();